<?php
// Simple database connection test
// Visit: yoursite.com/php-backend/test-connection.php

echo "<h2>Database Connection Test</h2>";

// Database configuration - UPDATE THESE WITH YOUR ACTUAL CREDENTIALS
$DB_HOST = 'localhost';
$DB_NAME = 'u370057811_LeadsDatabase';    // UPDATE THIS
$DB_USER = 'u370057811_umairsaif7';      // UPDATE THIS  
$DB_PASS = 'Umairsaif@7';      // UPDATE THIS

echo "<p><strong>Testing connection with:</strong></p>";
echo "<p>Host: $DB_HOST</p>";
echo "<p>Database: $DB_NAME</p>";
echo "<p>Username: $DB_USER</p>";
echo "<p>Password: " . str_repeat('*', strlen($DB_PASS)) . "</p>";

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
    
    echo "<p style='color: green;'><strong>✅ SUCCESS: Database connected successfully!</strong></p>";
    
    // Test if tables exist
    $tables = ['users', 'leads', 'categories', 'inquiries', 'payment_orders'];
    echo "<h3>Checking Tables:</h3>";
    
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $stmt->fetchColumn();
            echo "<p style='color: green;'>✅ Table '$table' exists with $count records</p>";
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Table '$table' missing or error: " . $e->getMessage() . "</p>";
        }
    }
    
    echo "<h3>Next Steps:</h3>";
    echo "<p>1. If tables are missing, import database_setup.sql in phpMyAdmin</p>";
    echo "<p>2. Update config.php with these same credentials</p>";
    echo "<p>3. Test API: <a href='api/leads.php'>api/leads.php</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'><strong>❌ ERROR: Database connection failed!</strong></p>";
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    
    echo "<h3>Common Solutions:</h3>";
    echo "<ul>";
    echo "<li>Check if database name '$DB_NAME' exists</li>";
    echo "<li>Verify username '$DB_USER' has access to database</li>";
    echo "<li>Check password is correct</li>";
    echo "<li>Ensure database server is running</li>";
    echo "</ul>";
}
?>